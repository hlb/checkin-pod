Checkin Pod｜Luma QR 報到測試包（10,000 人）

內容：
- luma-sample-10000.csv：10,000 位匿名測試來賓。
- 每 150 人為一組：前 100 位已有 checked_in_at，後 50 位尚未報到。
- pending-qrcodes/：第 101–110 位的 10 張 QR Code，可用掃描器或鏡頭測試報到。
- 150 人與 10,000 人範例的第 001–150 位使用相同 QR Code；兩份 ZIP 內的測試 QR 圖可以共用。

使用方式：
1. 在 /admin 匯入 luma-sample-10000.csv。
2. 開啟 /scan，或直接在 /admin 使用掃描器。
3. 依序掃描 pending-qrcodes 裡的 PNG；每張都對應 CSV 中一位尚未報到來賓。

所有姓名、Email、電話與 QR Code 都是測試資料，不對應真實人物或有效活動票券。
