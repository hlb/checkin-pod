抵達｜Luma QR 報到測試包

內容：
- luma-sample-150.csv：150 位匿名測試來賓。
- 第 001–100 位已有 checked_in_at，匯入後會顯示為已報到。
- 第 101–150 位尚未報到。
- pending-qrcodes/：第 101–110 位的 10 張 QR Code，可用掃描器或鏡頭測試報到。

使用方式：
1. 在 /admin 匯入 luma-sample-150.csv。
2. 開啟 /scan，或直接在 /admin 使用掃描器。
3. 依序掃描 pending-qrcodes 裡的 PNG；每張都對應 CSV 中一位尚未報到來賓。

所有姓名、Email、電話與 QR Code 都是測試資料，不對應真實人物或有效活動票券。
